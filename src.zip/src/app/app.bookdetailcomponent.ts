import { Component } from "@angular/core";

@Component({
    selector: 'book-info',
    templateUrl: './app.bookdetailcomponent.html'
})
export class BookDetailComponent{}