﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FrontPageComponent } from './app.frontpagecomponent';
import { ProgrammingCategoryComponent} from './app.programmingcategorycomponent';
import { BookListingComponent} from './app.booklistingcomponent';
import { BookDetailComponent } from './app.bookdetailcomponent';
import { StarRatingModule } from 'angular-star-rating';
import { LoginComponent } from './app.logincomponent';
import { CustomerProfileComponent } from './app.customerprofilecomponent';

@NgModule({
    imports: [
        BrowserModule,StarRatingModule
        
    ],
    declarations: [
        AppComponent,FrontPageComponent,ProgrammingCategoryComponent,BookListingComponent,BookDetailComponent,LoginComponent,
        CustomerProfileComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }