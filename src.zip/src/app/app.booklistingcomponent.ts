import { Component } from "@angular/core";

@Component({
    selector: 'book-listing',
    templateUrl: './app.booklistingcomponent.html'
})
export class BookListingComponent{}