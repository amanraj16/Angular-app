import { Component } from "../../node_modules/@angular/core";

@Component({
    selector:'customer-profile',
    templateUrl:'./app.customerprofilecomponent.html'
})
export class CustomerProfileComponent{}