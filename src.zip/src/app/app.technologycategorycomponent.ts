import { Component } from "@angular/core";

@Component({
    selector: 'technology-category',
    templateUrl: './app.technologycategorycomponent.html'
})
export class TechnologyCategoryComponent{}