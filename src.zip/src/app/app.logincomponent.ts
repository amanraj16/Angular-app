import { Component } from "../../node_modules/@angular/core";

@Component({
    selector:'login',
    templateUrl:'./app.logincomponent.html'
})
export class LoginComponent
{}