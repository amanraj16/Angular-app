import { Routes } from '@angular/router';
import { FrontPageComponent } from './app.frontpagecomponent';
import { ProgrammingCategoryComponent} from './app.programmingcategorycomponent';
import { LoginComponent } from './app.logincomponent';
import { BusinessCategoryComponent } from './app.businesscategorycomponent';
import { HistoryCategoryComponent } from './app.historycategorycomponent';
import { LifestyleCategoryComponent } from './app.lifestylecategorycomponent';
import { MarketingCategoryComponent } from './app.marketingcategorycomponent';
import { TechnologyCategoryComponent } from './app.technologycategorycomponent';
import { HealthCategoryComponent } from './app.healthcategorycomponent';

const appRoutes: Routes = [
    {
        path:'' ,redirectTo:'/home',pathMatch:"full"
    },
    { path: 'home', 
      component:  FrontPageComponent
    },
    { path: 'programming',
    component: ProgrammingCategoryComponent
  },
  {
      path:'login',
      component: LoginComponent
  },
  {
      path:'business',
      component:BusinessCategoryComponent
  },
  {
    path:'history',
    component:HistoryCategoryComponent
},
{
    path:'lifestyle',
    component:LifestyleCategoryComponent
},
{
    path:'marketing',
    component:MarketingCategoryComponent
},
{
    path:'technology',
    component:TechnologyCategoryComponent
},
{
    path:'health',
    component:HealthCategoryComponent
}
];
export default appRoutes;