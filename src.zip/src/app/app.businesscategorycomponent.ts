import { Component } from "@angular/core";

@Component({
    selector: 'business-category',
    templateUrl: './app.businesscategorycomponent.html'
})
export class BusinessCategoryComponent{}