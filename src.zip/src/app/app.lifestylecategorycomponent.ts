import { Component } from "@angular/core";

@Component({
    selector: 'lifestyle-category',
    templateUrl: './app.lifestylecategorycomponent.html'
})
export class LifestyleCategoryComponent{}