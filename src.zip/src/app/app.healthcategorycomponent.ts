import { Component } from "@angular/core";

@Component({
    selector: 'health-category',
    templateUrl: './app.healthcategorycomponent.html'
})
export class HealthCategoryComponent{}