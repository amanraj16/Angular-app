import { Component } from "@angular/core";

@Component({
    selector: 'history-category',
    templateUrl: './app.historycategorycomponent.html'
})
export class HistoryCategoryComponent{}