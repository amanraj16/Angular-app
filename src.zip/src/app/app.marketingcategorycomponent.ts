import { Component } from "@angular/core";

@Component({
    selector: 'marketing-category',
    templateUrl: './app.marketingcategorycomponent.html'
})
export class MarketingCategoryComponent{}