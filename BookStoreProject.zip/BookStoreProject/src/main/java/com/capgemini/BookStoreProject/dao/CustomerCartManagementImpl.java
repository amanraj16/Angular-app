package com.capgemini.BookStoreProject.dao;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.Category;




public class CustomerCartManagementImpl implements CustomerCartManagement {
	

	
	static Map<Integer,Cart> cartCollection = new HashMap<>();
	static {
		Book book = new Book();
		Category category = new Category();
		category.setCategoryId(500);
		category.setCategoryName("Comedy");
		book.setAuthorName("Shakespeare");
		book.setBookId(100);
		book.setBookImage("image.jpg");
		book.setCategory(category);
		book.setDesription("heath is welath");
		book.setIsbn("MOVS123");
		book.setPrice(123.56);
		book.setPublishDate(LocalDate.now());
		book.setQuantity(2);
		book.setRating(3);
		book.setTitle("Merchant Of Venice");
		Cart cart = new Cart(book,book.getPrice()*book.getQuantity(),book.getQuantity(),book.getBookId());
		cartCollection.put(book.getBookId(),cart);
	}
	
	
	@Override
	public void clearCart() {
		cartCollection.clear();
		
	}

	
	@Override
	public Map<Integer,Cart> removeABookFromCart(int cartId) {
		cartCollection.remove(cartId);
		return cartCollection;

	}

	@Override
	public Map<Integer,Cart> addABookToCart(Book book) {
		Cart cart = new Cart();
		cart.setQuantity(1);
		cart.setBook(book);
		cartCollection.put(book.getBookId(), cart);
		return cartCollection;
	}
	
	@Override
	public Map<Integer,Cart> addQuantityOfABook(int cartId) {
		Cart cart = cartCollection.get(cartId);
		cart.setQuantity(cart.getQuantity()+1);
		cartCollection.put(cartId,cart);
		return cartCollection;
	}

	@Override
	public Cart searchBook(int cartId) {
		Cart cart = cartCollection.get(cartId);
		return cart;
	}

	@Override
	public Map<Integer, Cart> decreaseQuantityOfABook(int cartId) {
		Cart cart = cartCollection.get(cartId);
		if(cart.getQuantity()  == 1)
		{
			cartCollection.remove(cartId);
			return cartCollection;
		}
		else {
			cart.setQuantity(cart.getQuantity()-1);
			cartCollection.put(cartId,cart);
			return cartCollection;
		}
	}


	@Override
	public Map<Integer, Cart> showAll() {
		
		return cartCollection;
	}


	@Override
	public double cartTotalPrice() { 
		double total = 0;
		for (Map.Entry<Integer,Cart> entry : cartCollection.entrySet())  {
						total = total + entry.getValue().getTotal();
						  
					} 
		return total;
			 

	}
	}
