import { OnInit, Component} from "../../node_modules/@angular/core";

@Component({
    selector:'<template-form></template-form>',
    templateUrl:'./app.templateformcomponent.html'
})
export class TemplateFormComponent implements OnInit
{
customer:any;
message:string;
constructor(){}
ngOnInit()
{
    this.customer={firstName:'Fred template'}
};
onSubmit(){
    this.message='You typed: '+this.customer.firstName;
}
}