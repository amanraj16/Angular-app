import { Component } from "../../node_modules/@angular/core";

@Component({
    selector: 'front-page',
    templateUrl: './app.frontpagecomponent.html'
})
export class FrontPageComponent{}