﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FrontPageComponent } from './app.frontpagecomponent';


@NgModule({
    imports: [
        BrowserModule
        
    ],
    declarations: [
        AppComponent,FrontPageComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }